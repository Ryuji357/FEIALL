function b = codifica(bloco)
  b = [];
  for c=1:64
    if sum(abs(bloco(c+1:end))) == 0
      b = [b; [1 dec2bin8(bloco(c))]];
      break
    else
      b = [b; [0 dec2bin8(bloco(c))]];
    endif
  endfor
endfunction