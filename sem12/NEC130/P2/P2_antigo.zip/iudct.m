function result = iudct(matriz)
  % Fun��o aplica dct
  % Aviso, importar o pacote signal
  result = idct2(matriz);
endfunction