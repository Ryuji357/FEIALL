function result = udct(matriz)
  % Fun��o aplica dct
  % Aviso, importar o pacote signal
  result = dct2(matriz);
endfunction