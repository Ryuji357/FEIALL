clear all
close all
clc

pkg load signal

X = imread('image.png'); % Carrega a imagem em X

% Dados da imagem
l_lin = size(X, 1);
l_col = size(X, 2);

% Matriz de quantiza��o
Q = [
16 11 10 16 24 40 51 61
12 12 14 19 26 58 60 55
14 13 16 24 40 57 69 56
14 17 22 29 51 87 80 62
18 22 37 56 68 109 103 77
24 35 55 64 81 104 113 92
49 64 78 87 103 121 120 101
72 92 95 98 112 100 103 99
];

%% Etapa 1
disp('Etapa 1');
% Extrai o RGB
R = im2double(X(:,:,1), 'indexed')-1; %separa o canal R na matriz R
G = im2double(X(:,:,2), 'indexed')-1; %separa o canal G na matriz G
B = im2double(X(:,:,3), 'indexed')-1; %separa o canal B na matriz B

% Calcula YCbCr
Y =  0.299*R + 0.587*G + 0.114*B; % Calcula o valor da lumin�ncia em fun��o de R,G,B
Cb = 128 - 0.168736*R - 0.331264*G + 0.5*B;% Calcula o valor de Cb em fun��o de R,G,B
Cr = 128 + 0.5*R - 0.418688*G - 0.081312*B;% Calcula o valor de Cr em fun��o de R,G,B

% Subamostragem 4:2:0
Cr_a = Cr(1:2:end, 1:2:end); % Amostra Cr
Cb_a = Cb(1:2:end, 1:2:end); % Amostra Cb

Crf = zeros(l_lin, l_col); % Nova matriz Cr
Cbf = zeros(l_lin, l_col); % Nova matriz Cb
for id=1:2
  for jd=1:2
    % Seta os valores reduzidos para rela��o com Y
    Crf(id:2:end, jd:2:end) = Cr_a;
    Cbf(id:2:end, jd:2:end) = Cb_a;
  endfor
endfor

% Desloca do range [0, 255] para [-128, 127]
Y_c = Y-128;
Cr_c = Crf-128;
Cb_c = Cbf-128;

% Variavel de coeficientes
l_coef = zeros(1, l_lin/8*l_col/8*3*64);
id = 1;

% Varre a imagem e separa em blocos de 8
for y = 1:8:l_lin
  for x = 1:8:l_col
    % Aplica a fun��o DCT, divide pela quantiz��o, ent�o aplica o zigzag
    l_coef(id:id+63) = zigzag(round(udct(Y_c(y:y+7, x:x+7))./Q));
    id = id + 64;
    l_coef(id:id+63) = zigzag(round(udct(Cr_c(y:y+7, x:x+7))./Q));
    id = id + 64;
    l_coef(id:id+63) = zigzag(round(udct(Cb_c(y:y+7, x:x+7))./Q));
    id = id + 64;
  endfor
  disp(y/l_lin);
endfor

l_coef = round(l_coef); % Erredonda os valores dos coeficientes

%% Etapa 2
disp('Etapa 2');
% Aplica os algoritmos de conver��o para cada um dos coeficientes
% A fun��o dec2bin8, converte decimal para binario
bin = [];
for i = 1:64:length(l_coef)
  bin = [bin; codifica(l_coef(i:i+63))];
  disp(i/length(l_coef));
endfor

%% Etapa 3
disp('Etapa 3');

% Reconstitui o vetor intero para realizar as opera��es inversas
rbin = zeros(l_lin/8*l_col/8*3*64, 8);
id = 1;
id2 = 1;
t = zeros(64, 8);
for ibin=1:length(bin)
  cbin = bin(ibin, :);
  t(mod(id2-1, 64)+1, :) = cbin(2:9);
  id2 = id2 + 1;
  if cbin(1) == 1
    rbin(id:id+63,:) = t;
    t = zeros(64, 8);
    id = id+64;
    id2 = 1;
  endif
endfor
l_dcoef = bin2dec(num2str(rbin(:,2:8))).-128*rbin(:,1);

% Subamostragem inversa 4:2:0
% Cria matrizes YCrCb
Y_d = zeros(l_lin, l_col);
Cr_d = zeros(l_lin, l_col);
Cb_d = zeros(l_lin, l_col);
id = 1;
for y = 1:8:l_lin
  for x = 1:8:l_col
    % Aplica a fun��o DCT, divide pela quantiz��o, ent�o aplica o zigzag
    Y_d(y:y+7, x:x+7) = iudct(izigzag(l_dcoef(id:id+63)).*Q);
    id = id + 64;
    Cr_d(y:y+7, x:x+7) = iudct(izigzag(l_dcoef(id:id+63)).*Q);
    id = id + 64;
    Cb_d(y:y+7, x:x+7) = iudct(izigzag(l_dcoef(id:id+63)).*Q);
    id = id + 64;
  endfor
endfor

% Volta para o range de [0, 255]
Y_f = Y_d + 128;
Cr_f = Cr_d + 128;
Cb_f = Cb_d + 128;

% Converte para RGB
Rf = Y_f + 1.402*(Cr_f - 128); %separa o canal R na matriz R
Gf = Y_f - 0.344136*(Cb_f - 128) - 0.714136*(Cr_f - 128); %separa o canal G na matriz G
Bf = Y_f + 1.772*(Cb_f - 128); %separa o canal B na matriz B

% Une RGB em uma variavel
Xf(:,:,1) = uint8(Rf);
Xf(:,:,2) = uint8(Gf);
Xf(:,:,3) = uint8(Bf);

imwrite(Xf, 'result.jpg');

figure('name', 'Compara��o das imagens.');

a = subplot(1,2,1);
imshow(X);
title('Original');
axis off;
axis('equal');

b = subplot(1,2,2);
imshow(Xf);
title('Reconstruido');
axis off;
axis('equal');

linkaxes([a, b]);

%% Final


%% Considera��es
% 1 - Foi dado foco em separar as etapas, ou seja, o passo-a-passo foi
%seguido independente da eficiencia