function [result] = juntar(R, G, B)
  result(:,:,1) = R;
  result(:,:,2) = G;
  result(:,:,3) = B;
endfunction